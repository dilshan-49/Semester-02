randomArray=randi([50,100],5,10);
tic;
VsinArray=sin(randomArray);
toc;
tic;
LsinArray=zeros(5,10);
for i=1:numel(randomArray)
    LsinArray(i)=sin(randomArray(i));
end
toc;