arr1=input("Enter Array1\n");
arr2=input("Enter Array2\n");

ArrayOut=compareArray(arr1,arr2)

function x=compareArray(array1,array2)
    if size(array1)==size(array2)
        x=zeros(size(array1,1),size(array1,2));
        for i=1:numel(array1)
            if array1(i)==array2(i)
                x(i)=1;
            end
        end
    else
        error('Different dimensions in input arrays')
    end
end
